import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RegistrationComponent} from './registration.component';
import {SharedModule} from '../shared.module';
import {RouterModule, Routes} from '@angular/router';
import {AppModule} from '../app.module';


const routes: Routes = [
  {
    path: '',
    component: RegistrationComponent,
    data: {
      title: ''
    }

  }
];

@NgModule({
  declarations: [
    RegistrationComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    SharedModule
  ]
})
export class RegistrationModule { }
