import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {RegistraionService} from '../service/registraion.service';
import {Router} from '@angular/router';
import {validate} from 'codelyzer/walkerFactory/walkerFn';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  regisrationform: FormGroup;
  User: any = {};

  constructor(public registrationservice: RegistraionService,
              private router: Router,
              private formBuilder: FormBuilder
  ) {
  }

  ngOnInit() {
    this.regisrationform = this.formBuilder.group
    ({
      name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]

    });
  }

  saveregister() {
    this.registrationservice.registera(this.User).subscribe(response => {
      console.log(response);
      return this.router.navigate(['/view']);
    });

    console.log(this.User);
  }

}
