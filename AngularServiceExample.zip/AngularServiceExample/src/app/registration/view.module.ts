import {RouterModule, Routes} from '@angular/router';

import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {CommonModule} from '@angular/common';
import {AppModule} from '../app.module';
import {SharedModule} from '../shared.module';
import {ViewComponent} from './view.component';


const routes: Routes = [
  {
    path: '',
    component: ViewComponent,
    data: {
      title: ''
    }

  }
];

// @ts-ignore
@NgModule({
  imports: [

    RouterModule.forChild(routes),
    SharedModule
  ],
  declarations: [
    ViewComponent
  ]
})

export class ViewModule {

}

