import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class RegistraionService {

  API_URL = 'http://testapi-php.local/';

  constructor(private http: HttpClient) { }

  Authnticate(User) {
    return this.http.post(this.API_URL + 'api/login', User);
  }
  registera(User) {
    return this.http.post(this.API_URL + 'api/register', User);
  }


}
