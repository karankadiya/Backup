import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {AppComponent} from './app.component';
import {RegistrationComponent} from './registration/registration.component';
import {BrowserModule} from '@angular/platform-browser';
import {AppRoutingModule} from './app-routing.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RegistraionService} from './service/registraion.service';
import {LoginService} from './service/loginservice.service';



@NgModule({
  declarations: [
         ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports:[
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
providers:[
  RegistraionService,
  LoginService
]

})
export class SharedModule { }
